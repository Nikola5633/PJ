package exercitiul2;

import java.io.*;
import java.util.Scanner;

public class MainApp2 {
    public static void main(String[]args) throws IOException {
        String nume_fis = "src/exercitiul2/in.txt ";
        BufferedReader flux_in;
        flux_in = new BufferedReader(new InputStreamReader(new FileInputStream(nume_fis)));
        String linie;
        while ((linie = flux_in.readLine()) != null)
        {
            System.out.println(flux_in.readLine());
        }
    }
}
