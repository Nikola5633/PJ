package exercitiul1;

import java.util.Scanner;

public class MainApp {
    public static void main(String[]args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("a=");
        int a=scanner.nextInt();
        System.out.println("Ati introdus valoarea "+a);
        System.out.print("b=");
        int b=scanner.nextInt();
        System.out.println("Ati introdus valoarea "+b);
        int A=a*b;
        System.out.println("Aria dreptunghiului  "+A);
        int P=(a+b)*2;
        System.out.println("Perimetrul dreptunghiului  "+P);
        scanner.close();
    }

}
