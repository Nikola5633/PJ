package ex3;

import java.util.Scanner;

public class MainApp3 {
    public static void main(String[]args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("n=");
        int n=scanner.nextInt();
        System.out.println("Ati introdus valoarea "+n);
        int nr=0;
        for(int d =1 ; d <= n ; d ++ ) {
            if (n % d == 0) {
                System.out.println("Divizorii " + d);
            }
        }
    }
}
