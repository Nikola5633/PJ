package ex2;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class MainApp2 {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("src/ex2/cantec_in.txt"));
        String linie;
        int id = 0;
        String[] c = new String[40];
        while ((linie = reader.readLine()) != null) {
            c[id] = linie;
            id++;

            System.out.println(" " + linie);
        }
    }
}
