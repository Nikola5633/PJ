package ex2;

public class Vers {
}
