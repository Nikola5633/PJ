package ex1;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("src/ex1/judete_in.txt"));
        String linie;
        int id=0;
        String[] judete = new String[3];
        while((linie=reader.readLine())!=null)
        {
            judete[id]=linie;
            id++;

            System.out.println(" "+linie);

        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduceti judetul: ");
        String judetCautat = scanner.nextLine();


        int pozitie = Arrays.binarySearch(judete, judetCautat);

        if (pozitie >= 0) {
            System.out.println("Judetul " + judetCautat + " se afla la pozitia " + (pozitie + 1) );
        } else {
            System.out.println("Judetul " + judetCautat + " nu a fost gasit în lista.");
        }
        scanner.close();
        reader.close();
    }
}
