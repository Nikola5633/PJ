package ex3;

    import java.util.Scanner;

public class MainApp3 {
        public static void main(String[] args) {

            Scanner scan= new Scanner(System.in);
            System.out.println("Introduceti primul sir ");
            String s1= scan.next();

            System.out.println("Introduceti al doilea sir ");
            String s2= scan.next();
            System.out.println("Pozitia");
            int n= scan.nextInt();

            String s3;
            s3=s1.substring(0,n)+s2+s1.substring(n);

            StringBuilder aux= new StringBuilder(s3);

            System.out.println("Pozitia stergere1:");
            int p1= scan.nextInt();
            System.out.println("cate caractere:");
            int nr= scan.nextInt();
            aux.delete(p1,p1+nr);

            System.out.println(aux);
        } }

